﻿using ProductMVC_AJ.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ProductMVC_AJ.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SearchResults()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> SearchResults(List<Product> model)
        {
            return View(model);
        }

        [HttpPost]
        public ActionResult Search(Product searchModel)
        {
            try
            {
                // Perform search and get results
                List<Product> searchResults = CallSearchStoredProcedure(searchModel);

                // Pass the search results to the SearchResults view
                return View("SearchResults", searchResults);
            }
            catch (Exception ex)
            {
                // Handle exceptions and display an error message
                ViewBag.ErrorMessage = $"Error during search: {ex.Message}";
                return View("SearchResults");
            }
        }

        public ActionResult CheckDatabaseConnection()
        {
            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Connection opened successfully
                    ViewBag.Message = "Database connection is successful!";
                }
            }
            catch (Exception ex)
            {
                // Connection failed
                ViewBag.Message = $"Database connection failed: {ex.Message}";
            }

            return View();
        }

        private List<Product> CallSearchStoredProcedure(Product searchModel)
        {
            List<Product> results = new List<Product>();

            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
            {
                using (SqlCommand command = new SqlCommand("usp_SearchProducts", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Add parameters
                    command.Parameters.AddWithValue("@ProductName", (object)searchModel.ProductName ?? DBNull.Value);
                    command.Parameters.AddWithValue("@Size", (object)searchModel.Size ?? DBNull.Value);
                    command.Parameters.AddWithValue("@Price", (object)searchModel.Price ?? DBNull.Value);
                    command.Parameters.AddWithValue("@MfgDate", (object)searchModel.MfgDate ?? DBNull.Value);
                    command.Parameters.AddWithValue("@Category", (object)searchModel.Category ?? DBNull.Value);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductId = Convert.ToInt32(reader["ProductId"]),
                                ProductName = reader["ProductName"].ToString(),
                                Size = reader["Size"].ToString(),
                                Price = Convert.ToDecimal(reader["Price"]),
                                MfgDate = Convert.ToDateTime(reader["MfgDate"]),
                                Category = reader["Category"].ToString()
                            };

                            results.Add(product);
                        }
                    }
                }
            }

            return results;
        }
    }
}
